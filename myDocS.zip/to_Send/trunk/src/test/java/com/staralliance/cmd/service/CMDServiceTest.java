/*
 * Copyright - StarAlliance GmbH
 */
package com.staralliance.cmd.service;

import static org.junit.Assert.assertEquals;

import org.easymock.Mock;
import org.junit.BeforeClass;
import org.junit.Test;

import com.staralliance.cmd.domain.Coordinates;
import com.staralliance.cmd.domain.Direction;
import com.staralliance.cmd.domain.OriginDestinationPair;
import com.staralliance.cmd.domain.Station;
import com.staralliance.cmd.exception.StarHubException;
import com.staralliance.cmd.interfaces.CMDService;
import com.staralliance.cmd.service.endpoint.StarHubServices;

public class CMDServiceTest {

    @Mock
    private static OriginDestinationPair odpair;
    @Mock
    private static Station origin;
    @Mock
    private static Station destination;

    private double miles;

    @BeforeClass
    public static void init() {
        origin = new Station("AAL", new Coordinates(57.1, Direction.NORTH),
                new Coordinates(9.86, Direction.EAST));
        destination = new Station("AGP",
                new Coordinates(36.67, Direction.NORTH),
                new Coordinates(4.5, Direction.WEST));
        odpair = new OriginDestinationPair(origin, destination);
    }

    @Test
    public void testMilesCalculationWithCoordinates() {
        try {
            CMDService cmdService = StarHubServices.newCMDService()
                    .withCoordinates(odpair);
            miles = cmdService.getMiles();
        } catch (StarHubException e) {
            System.err.println("Star Hub Exception :: " + e.getCause());
        }
        assertEquals("error in miles calculation", 1557, miles, 0);
    }

    @Test
    public void testDefaultMiles() {
        try {
            CMDService cmdService = StarHubServices.newCMDService();
            miles = cmdService.getMiles();
        } catch (StarHubException e) {
            System.err.println("Star Hub Exception :: " + e.getCause());
        }
        assertEquals("error in miles calculation", 0.0d, miles, 0);
    }

    @Test
    public void testEnum() {
        String direction = Direction.SOUTH.toString();
        assertEquals("Enum error", "SOUTH", direction);
        ;
    }
}
