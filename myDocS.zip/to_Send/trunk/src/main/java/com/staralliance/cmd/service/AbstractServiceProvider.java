/*
 * Copyright - StarAlliance GmbH
 */
package com.staralliance.cmd.service;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.staralliance.cmd.exception.StarHubException;
import com.staralliance.cmd.interfaces.CMDService;

/**
 * The Class AbstractServiceProvider. Exposes methods to create a new instance
 * for CMD service type and to cache the created instances
 */
public abstract class AbstractServiceProvider {

    private static final Map<String, CMDService> cmdServiceProvider = new ConcurrentHashMap<String, CMDService>();
    private static final String CMD_PROVIDER_NAME = "cmdInstance";

    /**
     * New CMD service.
     *
     * @return the CMD service
     * @throws StarHubException
     *             the star hub exception
     */
    public static CMDService newCMDService() throws StarHubException {
        CMDService cmdService = cmdServiceProvider.get(CMD_PROVIDER_NAME);
        if (cmdService == null) {
            registerCMDService();
            return cmdServiceProvider.get(CMD_PROVIDER_NAME);
        }
        return cmdService;
    }

    /**
     * Register CMD service.
     *
     * @throws StarHubException
     *             the star hub exception
     */
    protected static void registerCMDService() throws StarHubException {
        Constructor<StarCMDMilesCalculator> constructor;
        try {
            constructor = getCMDServiceContructor(StarCMDMilesCalculator.class);
            constructor.setAccessible(true);
            CMDService cmdService = constructor.newInstance();
            cmdServiceProvider.put(CMD_PROVIDER_NAME, cmdService);
        } catch (SecurityException e) {
            throw new StarHubException(e.getMessage(), e.getCause());
        } catch (InstantiationException e) {
            throw new StarHubException(e.getMessage(), e.getCause());
        } catch (IllegalAccessException e) {
            throw new StarHubException(e.getMessage(), e.getCause());
        } catch (IllegalArgumentException e) {
            throw new StarHubException(e.getMessage(), e.getCause());
        } catch (InvocationTargetException e) {
            Throwable c = e.getTargetException();
            throw new StarHubException(c == null ? e : c);
        }

    }

    /**
     * Gets the CMD service contructor.
     *
     * @param clazz
     *            the clazz
     * @return the CMD service contructor
     * @throws StarHubException
     *             the star hub exception
     */
    protected static Constructor<StarCMDMilesCalculator> getCMDServiceContructor(
            Class<StarCMDMilesCalculator> clazz) throws StarHubException {
        try {
            return clazz.getDeclaredConstructor();
        } catch (NoSuchMethodException e) {
            throw new StarHubException(e.getMessage(), e.getCause());
        } catch (SecurityException e) {
            throw new StarHubException(e.getMessage(), e.getCause());
        }
    }

}
