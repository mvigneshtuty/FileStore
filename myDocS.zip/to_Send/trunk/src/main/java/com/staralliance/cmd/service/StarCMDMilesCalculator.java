/*
 * Copyright - StarAlliance GmbH
 */
package com.staralliance.cmd.service;

import com.staralliance.cmd.domain.Coordinates;
import com.staralliance.cmd.domain.OriginDestinationPair;
import com.staralliance.cmd.domain.Station;
import com.staralliance.cmd.interfaces.CMDService;
import com.staralliance.cmd.util.StarHub;

/**
 * The Class StarCMDMilesCalculator. Implementation class of CMD service
 * exposing the methods to calculate the miles based on the coordinates of
 * origin and destination
 */
public final class StarCMDMilesCalculator implements CMDService {

    private OriginDestinationPair odPair;
    private final double C_PI = Math.PI;

    /**
     * Star CMD miles calculator - Private constructor to prevent creation of
     * instances by clients. Clients can make use of static factory methods
     * exposed via StarHubServices class to get the new CMD service instances.
     */
    private StarCMDMilesCalculator() {

    }

    /**
     * Instantiates a new star CMD miles calculator.
     *
     * @param odPair
     *            the od pair
     */
    private StarCMDMilesCalculator(OriginDestinationPair odPair) {
        this.odPair = odPair;
    }

    /*
     * (non-Javadoc)
     *
     * @see com.staralliance.cmd.interfaces.CMDService#withCoordinates(com.
     * staralliance.cmd.domain.OriginDestinationPair)
     */
    @Override
    public CMDService withCoordinates(OriginDestinationPair odPair) {
        return new StarCMDMilesCalculator(odPair);
    }

    /*
     * (non-Javadoc)
     *
     * @see com.staralliance.cmd.interfaces.CMDService#getMiles()
     */
    /*
     *
     * @see com.staralliance.cmd.interfaces.CMDService#getMiles()
     */
    @Override
    public double getMiles() {
        if (this.odPair == null) {
            return StarHub.CMD_DEFAULT.miles();
        }
        return calculateMiles(this.odPair);
    }

    /**
     * Calculate miles.
     *
     * @param odPair
     *            the od pair
     * @return the double
     */
    private double calculateMiles(OriginDestinationPair odPair) {
        odPair = refactorToRadians(odPair);
        return applyAlgorithm(odPair.getOrigin(), odPair.getDestination());
    }

    /**
     * Apply algorithm.
     *
     * @param origin
     *            the origin
     * @param destination
     *            the destination
     * @return the double
     */
    private double applyAlgorithm(Station origin, Station destination) {

        double DstHorz;
        double AngSin;
        double SAng;
        double calculateAirportDistance;
        double ori_lat = origin.getLatitude().getValue();
        double ori_long = origin.getLongitude().getValue();
        double dest_lat = destination.getLatitude().getValue();
        double dest_long = destination.getLongitude().getValue();

        DstHorz = Math.abs(ori_long - (dest_long));
        if (DstHorz > C_PI) {
            DstHorz = (2 * C_PI) - DstHorz;
        }

        /**
         * formula : AngSin = Cos((C_PI / 2) - ori_lat) * Cos((C_PI / 2) -
         * dest_lat) + Sin((C_PI / 2) - ori_lat) * Sin((C_PI / 2) - dest_lat) *
         * Cos(DstHorz)
         */

        AngSin = Math.cos((C_PI / 2) - ori_lat)
                * Math.cos((C_PI / 2) - dest_lat)
                + Math.sin((C_PI / 2) - ori_lat)
                        * Math.sin((C_PI / 2) - dest_lat) * Math.cos(DstHorz);

        /**
         * formula :
         *
         * SAng = Atn(Sqr(1 - (AngSin * AngSin)) / AngSin)
         */
        SAng = Math.atan(Math.sqrt(1 - (AngSin * AngSin)) / AngSin);
        if (SAng < 0) {
            SAng = SAng + C_PI;
        }
        /**
         * formula :
         *
         * calculateAirportDistance = Round(((SAng * 69 * 180) / C_PI), 0)
         *
         */

        calculateAirportDistance = Math.rint(((SAng * 69 * 180) / C_PI));
        return calculateAirportDistance;
    }

    /**
     * Refactor to radians.
     *
     * @param odPair
     *            the od pair
     * @return the origin destination pair
     */
    private OriginDestinationPair refactorToRadians(
            OriginDestinationPair odPair) {

        // Origin
        Station origin = odPair.getOrigin();
        Coordinates originLat = origin.getLatitude();
        Coordinates originLong = origin.getLongitude();
        // Destination
        Station destination = odPair.getDestination();
        Coordinates destLat = destination.getLatitude();
        Coordinates destLong = destination.getLongitude();

        // get the latitude-longitude coordinates
        double ori_lat = Math.toRadians(originLat.getValue());
        double ori_long = Math.toRadians(originLong.getValue());
        double dest_lat = Math.toRadians(destLat.getValue());
        double dest_long = Math.toRadians(destLong.getValue());

        // refactor coordinates based on direction

        originLat = new Coordinates(
                (originLat.getDirection().toString() == "SOUTH") ? ori_lat * -1
                        : ori_lat,
                originLat.getDirection());
        originLong = new Coordinates(
                (originLong.getDirection().toString() == "EAST") ? ori_long * -1
                        : ori_long,
                originLong.getDirection());
        destLat = new Coordinates((destLat.getDirection().toString() == "SOUTH")
                ? dest_lat * -1 : dest_lat, destLat.getDirection());
        destLong = new Coordinates(
                (destLong.getDirection().toString() == "EAST") ? dest_long * -1
                        : dest_long,
                destLong.getDirection());

        origin = new Station(origin.getStationCode(), originLat, originLong);
        destination = new Station(destination.getStationCode(), destLat,
                destLong);
        return new OriginDestinationPair(origin, destination);

    }

}
