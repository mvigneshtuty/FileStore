/*
 * Copyright - StarAlliance GmbH
 */
package com.staralliance.cmd.service.endpoint;

import com.staralliance.cmd.exception.StarHubException;
import com.staralliance.cmd.interfaces.CMDService;
import com.staralliance.cmd.service.AbstractServiceProvider;

/**
 * The Class StarHubServices. The CMD service access class to get the instance
 * of CMD service implementation. This class is the single entry point for CMD
 * service.
 */
public class StarHubServices {

    /**
     * StarHubServices - Private constructor. Prevents creation of new instances
     * of StarHubServices class by clients. Clients can make use of a exposed
     * public static factory method which returns a new CMD service instance.
     */
    private StarHubServices() {

    }

    /**
     * Convenience method for accessing CMD service. Returns new CMD service
     * instance.
     *
     * @return the CMD service
     * @throws StarHubException
     *             the star hub exception
     */
    public static CMDService newCMDService() throws StarHubException {
        return AbstractServiceProvider.newCMDService();
    }

}
