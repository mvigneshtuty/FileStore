/*
 * Copyright - StarAlliance GmbH
 */
package com.staralliance.cmd.util;

public enum StarHub {

    CMD_DEFAULT(0.0d);

    private final double miles;

    /**
     * Instantiates a new star hub.
     *
     * @param miles
     *            the miles
     */
    StarHub(double miles) {
        this.miles = miles;
    }

    public double miles() {
        return this.miles;
    }

}
