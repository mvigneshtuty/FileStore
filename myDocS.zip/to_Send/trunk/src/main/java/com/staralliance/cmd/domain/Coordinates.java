/*
 * Copyright - StarAlliance GmbH
 */
package com.staralliance.cmd.domain;

/**
 * The Class Coordinates. Domain class for holding the values of
 * latitude/longitude value type and its direction
 */
public class Coordinates {

    /** The value. */
    private final double value;

    /** The direction. */
    private final Direction direction;

    /**
     * Instantiates a new coordinates.
     *
     * @param value
     *            the value
     * @param direction
     *            the direction
     */
    public Coordinates(double value, Direction direction) {
        this.value = value;
        this.direction = direction;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public double getValue() {
        return value;
    }

    /**
     * Gets the direction.
     *
     * @return the direction
     */
    public Direction getDirection() {
        return direction;
    }

    /**
     * Returns a description of coordinates with value and direction.
     *
     * "Coordinates [value=value, direction=direction-value]".
     *
     * @return the string
     */

    @Override
    public String toString() {
        return "Coordinates [value=" + value + ", direction=" + direction + "]";
    }
}
