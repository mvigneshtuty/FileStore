/*
 * Copyright - StarAlliance GmbH
 */
package com.staralliance.cmd.exception;

// TODO: Auto-generated Javadoc
/**
 * The Class StarHubException. Custom Exception class for handling the CMD
 * service exceptions. Client of CMD service have to catch this exception with
 * appropriate error messages
 */
public class StarHubException extends Exception {

    /** Serializable version identifier. */
    private static final long serialVersionUID = -7323112435297514533L;

    /**
     * The underlying cause of this exception.
     */
    protected Throwable cause = null;

    /**
     * Construct a new exception with the specified detail message and cause.
     *
     * @param message
     *            The detail message
     * @param cause
     *            The underlying cause
     */
    public StarHubException(String message, Throwable cause) {
        super(message + " (Caused by " + cause + ")");
        this.cause = cause;
    }

    /**
     * Construct a new exception with <code>null</code> as its detail message.
     */
    public StarHubException() {
        super();
    }

    /**
     * Construct a new exception with the specified detail message.
     *
     * @param message
     *            The detail message
     */
    public StarHubException(String message) {
        super(message);
    }

    /**
     * Construct a new exception with the specified cause and a derived detail
     * message.
     *
     * @param cause
     *            The underlying cause
     */
    public StarHubException(Throwable cause) {
        this(cause == null ? null : cause.toString(), cause);
    }

    /**
     * Returns a description of StarHubException with cause.
     *
     * "StarHubException [cause=cause]"
     *
     * @return the string
     */
    @Override
    public String toString() {
        return "StarHubException [cause=" + cause + "]";
    }

}
