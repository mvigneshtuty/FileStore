/*
 * Copyright - StarAlliance GmbH
 */

package com.staralliance.cmd.interfaces;

import com.staralliance.cmd.domain.OriginDestinationPair;

// TODO: Auto-generated Javadoc
/**
 * The Interface CMDService. Interface for accessing the CMD services which
 * provides methods to calculate the miles.
 *
 */
public interface CMDService {

    /**
     * Gets the miles.
     *
     * @return the miles
     */
    double getMiles();

    /**
     * With coordinates.
     *
     * @param coordinates
     *            the coordinates
     * @return the CMD service
     */
    CMDService withCoordinates(OriginDestinationPair coordinates);
}
