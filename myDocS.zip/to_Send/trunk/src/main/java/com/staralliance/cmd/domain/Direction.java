/*
 * Copyright - StarAlliance GmbH
 */
package com.staralliance.cmd.domain;

/**
 * The Enum Direction. Enum of directions used for latitude and longitude
 */
public enum Direction {
    NORTH, EAST, WEST, SOUTH;
}
