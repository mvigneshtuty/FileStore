/*
 * Copyright - StarAlliance GmbH
 */
package com.staralliance.cmd.domain;

/**
 * The Class OriginDestinationPair. Domain class to hold the origin and
 * destination attributes
 */
public class OriginDestinationPair {

    /** The origin. */
    private final Station origin;

    /** The destination. */
    private final Station destination;

    /**
     * Instantiates a new origin destination pair.
     *
     * @param origin
     *            the origin
     * @param destination
     *            the destination
     */
    public OriginDestinationPair(Station origin, Station destination) {
        this.origin = origin;
        this.destination = destination;
    }

    /**
     * Gets the origin.
     *
     * @return the origin
     */
    public Station getOrigin() {
        return origin;
    }

    /**
     * Gets the destination.
     *
     * @return the destination
     */
    public Station getDestination() {
        return destination;
    }

    /**
     * Returns a description of OriginDestinationPair with origin and
     * destination values. "OriginDestinationPair [origin=origin-value,
     * destination=destination-value]"
     *
     * @return the string
     */

    @Override
    public String toString() {
        return "OriginDestinationPair [origin=" + origin + ", destination="
                + destination + "]";
    }

}
