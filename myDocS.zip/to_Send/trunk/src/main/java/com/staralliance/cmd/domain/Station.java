/*
 * Copyright - StarAlliance GmbH
 */
package com.staralliance.cmd.domain;

/**
 * The Class Station. Domain class to hold the stationCode, latitide and
 * longitude attributes
 */
public class Station {

    /** The station code. */
    private final String stationCode;

    /** The latitude. */
    private final Coordinates latitude;

    /** The longitude. */
    private final Coordinates longitude;

    /**
     * Instantiates a new station.
     *
     * @param stationCode
     *            the station code
     * @param latitude
     *            the latitude
     * @param longitude
     *            the longitude
     */
    public Station(String stationCode, Coordinates latitude,
            Coordinates longitude) {
        this.stationCode = stationCode;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    /**
     * Gets the station code.
     *
     * @return the station code
     */
    public String getStationCode() {
        return stationCode;
    }

    /**
     * Gets the latitude.
     *
     * @return the latitude
     */
    public Coordinates getLatitude() {
        return latitude;
    }

    /**
     * Gets the longitude.
     *
     * @return the longitude
     */
    public Coordinates getLongitude() {
        return longitude;
    }

    /**
     * Returns a description of Station with station code, latitude and
     * longitude values.
     *
     * "Station [stationCode=stationCode, latitude=latitude-value,
     * longitude=longitude-value]"
     *
     * @return the string
     */

    @Override
    public String toString() {
        return "Station [stationCode=" + stationCode + ", latitude=" + latitude
                + ", longitude=" + longitude + "]";
    }
}
